import Link from "next/link";
import { vehicles } from "@/lib/mock-data";

export default function HomePage() {
  return (
    <>
      <section className="hero">
        <div className="container hero-grid">
          <div>
            <span className="badge">Marketplace pou Ayiti ak dyaspora a</span>
            <h1>Lwe yon machin ann Ayiti ak plis konfyans.</h1>
            <p>Rezève pou tèt ou oswa pou yon fanmi, peye an USD, epi jwenn machin nan nan vil oswa ayewopò ou chwazi.</p>
          </div>
          <form className="search-panel" action="/vehicles">
            <div className="grid">
              <div className="field">
                <label>Vil oswa ayewopò</label>
                <select name="city" defaultValue="Cap-Haïtien">
                  <option>Cap-Haïtien</option>
                  <option>Port-au-Prince</option>
                  <option>Les Cayes</option>
                </select>
              </div>
              <div className="grid grid-2">
                <div className="field"><label>Pran</label><input type="date" name="start" /></div>
                <div className="field"><label>Retounen</label><input type="date" name="end" /></div>
              </div>
              <button className="btn btn-primary" type="submit">Chèche machin</button>
            </div>
          </form>
        </div>
      </section>
      <section className="section">
        <div className="container">
          <div className="row"><h2>Machin rekòmande</h2><Link href="/vehicles">Wè tout</Link></div>
          <div className="grid grid-3">
            {vehicles.map(v => (
              <Link className="card" href={`/vehicles/${v.id}`} key={v.id}>
                <div className="car-image" />
                <div className="card-body">
                  <div className="row">
                    <div>
                      <b>{v.make} {v.model} {v.year}</b>
                      <div className="muted">{v.city} • {v.transmission}</div>
                    </div>
                    <div className="price">${v.pricePerDay}/jou</div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

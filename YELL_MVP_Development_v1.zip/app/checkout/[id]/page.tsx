import { notFound } from "next/navigation";
import { vehicles } from "@/lib/mock-data";
import Link from "next/link";

export default function CheckoutPage({ params }: { params: { id: string } }) {
  const vehicle = vehicles.find(v => v.id === params.id);
  if (!vehicle) notFound();
  const rental = vehicle.pricePerDay * 5;
  const delivery = 25;
  const serviceFee = 30;
  const total = rental + delivery + serviceFee + vehicle.deposit;
  return (
    <section className="section">
      <div className="container grid grid-2">
        <div>
          <h1>Konfime rezèvasyon an</h1>
          <div className="notice">
            Depo a pa revni pwopriyetè a. Li rete apa epi li retounen apre enspeksyon, sof si YELL valide yon reklamasyon ak prèv.
          </div>
          <div className="card" style={{marginTop: 18}}>
            <div className="card-body">
              <h3>Kondisyon depo sekirite</h3>
              <p>✓ Pa gen nouvo domaj.</p>
              <p>✓ Machin nan retounen alè.</p>
              <p>✓ Gaz ak kilomèt respekte kontra a.</p>
              <p>✓ Pa gen kle pèdi, fimen, tikè oswa netwayaj ekstraòdinè.</p>
            </div>
          </div>
        </div>
        <div className="summary">
          <h2>{vehicle.make} {vehicle.model}</h2>
          <div className="summary-row"><span>Lokasyon (5 jou)</span><b>${rental}</b></div>
          <div className="summary-row"><span>Livrezon ayewopò</span><b>${delivery}</b></div>
          <div className="summary-row"><span>Frè sèvis YELL</span><b>${serviceFee}</b></div>
          <div className="summary-row"><span>Depo sekirite</span><b>${vehicle.deposit}</b></div>
          <div className="summary-row total"><span>Total otorize</span><span>${total}</span></div>
          <Link className="btn btn-primary" style={{width:"100%", marginTop: 16}} href="/booking-success">
            Konfime epi peye
          </Link>
        </div>
      </div>
    </section>
  );
}

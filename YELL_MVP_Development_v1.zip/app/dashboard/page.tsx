import Link from "next/link";

export default function DashboardPage() {
  return (
    <div className="dashboard">
      <aside className="sidebar">
        <h3>Dashboard</h3>
        <Link href="/dashboard">Rezime</Link>
        <Link href="/vehicles">Machin</Link>
        <Link href="/host">Ajoute machin</Link>
        <Link href="/">Peman</Link>
        <Link href="/">Reklamasyon</Link>
      </aside>
      <main className="dashboard-main">
        <h1>Bonjou, Alain</h1>
        <div className="grid grid-3">
          <div className="metric"><span className="muted">Machin aktif</span><br/><b>4</b></div>
          <div className="metric"><span className="muted">Booking mwa sa a</span><br/><b>12</b></div>
          <div className="metric"><span className="muted">Revni mwa sa a</span><br/><b>$1,845</b></div>
        </div>
        <div className="card" style={{marginTop: 24}}>
          <div className="card-body">
            <h2>Rezèvasyon k ap vini</h2>
            <div className="summary-row"><span>Toyota RAV4 • 12–17 Out</span><b>Depo $250 otorize</b></div>
          </div>
        </div>
      </main>
    </div>
  );
}

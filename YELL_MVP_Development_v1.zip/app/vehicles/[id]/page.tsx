import { notFound } from "next/navigation";
import Link from "next/link";
import { vehicles } from "@/lib/mock-data";

export default function VehicleDetail({ params }: { params: { id: string } }) {
  const vehicle = vehicles.find(v => v.id === params.id);
  if (!vehicle) notFound();
  return (
    <section className="section">
      <div className="container grid grid-2">
        <div className="card">
          <div className="car-image" style={{height: 360}} />
          <div className="card-body">
            <span className="badge">✓ Verified Owner</span>
            <h1>{vehicle.make} {vehicle.model} {vehicle.year}</h1>
            <p className="muted">{vehicle.city} • {vehicle.transmission} • {vehicle.category}</p>
            <h3>Pwopriyetè: {vehicle.host}</h3>
            <p>Airport delivery, Book for Someone Else, foto enspeksyon anvan/apre, ak depo sekirite ranbousab.</p>
          </div>
        </div>
        <div className="card">
          <div className="card-body">
            <h2>${vehicle.pricePerDay}/jou</h2>
            <form className="grid" action={`/checkout/${vehicle.id}`}>
              <div className="grid grid-2">
                <div className="field"><label>Pran</label><input type="date" name="start" required /></div>
                <div className="field"><label>Retounen</label><input type="date" name="end" required /></div>
              </div>
              <div className="field">
                <label>Kiyès k ap pran machin nan?</label>
                <select name="recipient"><option>Mwen menm</option><option>Yon lòt moun</option></select>
              </div>
              <div className="field">
                <label>Kote remiz</label>
                <select name="pickup"><option>Ayewopò</option><option>Biwo pwopriyetè</option><option>Livrezon</option></select>
              </div>
              <div className="notice">Depo sekirite: <b>${vehicle.deposit}</b>. Li ranbousab si machin nan retounen dapre kontra a.</div>
              <button className="btn btn-primary" type="submit">Kontinye ak rezèvasyon</button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

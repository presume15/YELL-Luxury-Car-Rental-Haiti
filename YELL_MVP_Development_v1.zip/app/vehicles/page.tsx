import Link from "next/link";
import { vehicles } from "@/lib/mock-data";

export default function VehiclesPage() {
  return (
    <section className="section">
      <div className="container">
        <div className="row">
          <div><h2>Machin disponib</h2><p className="muted">Chwazi yon machin verifye.</p></div>
          <Link className="btn btn-outline" href="/">Modifye rechèch</Link>
        </div>
        <div className="grid grid-3">
          {vehicles.map(v => (
            <Link className="card" href={`/vehicles/${v.id}`} key={v.id}>
              <div className="car-image" />
              <div className="card-body">
                <span className="badge">✓ Verified Owner</span>
                <h3>{v.make} {v.model} {v.year}</h3>
                <div className="muted">★ {v.rating} • {v.city}</div>
                <div className="row" style={{marginTop: 14}}>
                  <span>{v.category}</span><span className="price">${v.pricePerDay}/jou</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

import Link from "next/link";

export default function SuccessPage() {
  return (
    <section className="section">
      <div className="container" style={{maxWidth: 680, textAlign: "center"}}>
        <div style={{fontSize: 72}}>✅</div>
        <h1>Rezèvasyon konfime</h1>
        <p className="muted">Kòd rezèvasyon: YELL-48219</p>
        <div className="card">
          <div className="card-body">
            <div className="summary-row"><span>Estati peman</span><b>Otorize</b></div>
            <div className="summary-row"><span>Depo sekirite</span><b>$250</b></div>
            <div className="summary-row"><span>Estati depo</span><b style={{color:"var(--success)"}}>Kenbe separeman</b></div>
          </div>
        </div>
        <Link className="btn btn-dark" style={{marginTop: 20}} href="/dashboard">Wè dashboard</Link>
      </div>
    </section>
  );
}

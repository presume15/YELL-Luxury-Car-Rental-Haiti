export default function HostPage() {
  return (
    <section className="section">
      <div className="container" style={{maxWidth: 760}}>
        <h1>Ajoute yon machin</h1>
        <p className="muted">Machin nan p ap parèt jiskaske YELL verifye dokiman yo.</p>
        <form className="card">
          <div className="card-body grid">
            <div className="grid grid-2">
              <div className="field"><label>Mak</label><input placeholder="Toyota" /></div>
              <div className="field"><label>Modèl</label><input placeholder="RAV4" /></div>
            </div>
            <div className="grid grid-2">
              <div className="field"><label>Ane</label><input type="number" placeholder="2022" /></div>
              <div className="field"><label>Vil</label><input placeholder="Cap-Haïtien" /></div>
            </div>
            <div className="grid grid-2">
              <div className="field"><label>Pri pa jou (USD)</label><input type="number" placeholder="65" /></div>
              <div className="field"><label>Depo sekirite (USD)</label><input type="number" placeholder="250" /></div>
            </div>
            <div className="field"><label>Dokiman machin</label><input type="file" /></div>
            <button className="btn btn-primary" type="button">Soumèt pou verifikasyon</button>
          </div>
        </form>
      </div>
    </section>
  );
}

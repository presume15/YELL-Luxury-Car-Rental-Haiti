import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "YELL Car Rental Haiti",
  description: "Marketplace lokasyon machin pou Ayiti ak dyaspora a"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ht">
      <body>
        <nav className="nav">
          <div className="container nav-inner">
            <Link href="/" className="brand">
              <span className="logo">Y</span>
              <span>YELL Car Rental Haiti</span>
            </Link>
            <div className="nav-links">
              <Link href="/vehicles">Machin</Link>
              <Link href="/host">Mete machin ou</Link>
              <Link href="/dashboard">Dashboard</Link>
              <Link href="/login">Konekte</Link>
            </div>
          </div>
        </nav>
        {children}
        <footer className="footer">
          <div className="container">© 2026 YELL Luxury Transportation — Haiti & Diaspora</div>
        </footer>
      </body>
    </html>
  );
}

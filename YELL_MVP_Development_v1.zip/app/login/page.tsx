export default function LoginPage() {
  return (
    <section className="section">
      <div className="container" style={{maxWidth: 520}}>
        <form className="card">
          <div className="card-body grid">
            <h1>Konekte</h1>
            <div className="field"><label>Imèl</label><input type="email" /></div>
            <div className="field"><label>Modpas</label><input type="password" /></div>
            <button className="btn btn-primary" type="button">Konekte</button>
          </div>
        </form>
      </div>
    </section>
  );
}

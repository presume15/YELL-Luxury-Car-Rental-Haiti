# YELL Car Rental Haiti — MVP v1

Premye baz devlopman pou marketplace lokasyon machin YELL.

## Fonksyon ki deja nan starter la

- Paj dakèy ak rechèch
- Lis machin
- Detay machin
- Rezèvasyon pou tèt ou oswa yon lòt moun
- Checkout ak depo sekirite
- Konfimasyon booking
- Dashboard pwopriyetè
- Fòm pou ajoute machin
- Baz done Supabase
- Tab pou enspeksyon, reklamasyon, peman ak depo

## Kòmanse lokalman

1. Enstale Node.js 20+
2. Kopye `.env.example` kòm `.env.local`
3. Mete kle Supabase yo
4. Kouri:

```bash
npm install
npm run dev
```

5. Ouvri `http://localhost:3000`

## Baz done

Kouri `supabase/schema.sql` nan Supabase SQL Editor.

## Depo sekirite

Vèsyon sa a montre lojik UX ak estrikti baz done a. Pou pwodiksyon:
- itilize yon payment provider ki sipòte authorization/capture;
- kenbe depo a kòm yon authorization apa;
- pa transfere li bay host la;
- libere li apre enspeksyon;
- nenpòt capture dwe pase pa sistèm reklamasyon YELL.

## Pwochen modil

- Supabase Auth reyèl
- Upload foto/dokiman
- Stripe Connect oswa lòt founisè peman
- Admin verification dashboard
- Booking calendar
- Chat ak notifications
- Multilingual HT/FR/EN/ES

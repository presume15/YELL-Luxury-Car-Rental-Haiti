export const vehicles = [
  {
    id: "rav4-2022",
    make: "Toyota",
    model: "RAV4",
    year: 2022,
    city: "Cap-Haïtien",
    pricePerDay: 65,
    deposit: 250,
    rating: 4.9,
    host: "Jean-Pierre Rentals",
    category: "SUV",
    transmission: "Automatic"
  },
  {
    id: "tucson-2021",
    make: "Hyundai",
    model: "Tucson",
    year: 2021,
    city: "Port-au-Prince",
    pricePerDay: 58,
    deposit: 250,
    rating: 4.8,
    host: "Haiti Drive",
    category: "SUV",
    transmission: "Automatic"
  },
  {
    id: "sportage-2020",
    make: "Kia",
    model: "Sportage",
    year: 2020,
    city: "Les Cayes",
    pricePerDay: 52,
    deposit: 200,
    rating: 4.7,
    host: "Sud Auto Rental",
    category: "SUV",
    transmission: "Automatic"
  }
];

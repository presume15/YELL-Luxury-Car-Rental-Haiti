-- YELL Car Rental Haiti MVP schema
create extension if not exists "uuid-ossp";

create type user_role as enum ('renter','host','rental_company','admin');
create type verification_status as enum ('pending','approved','rejected');
create type booking_status as enum ('pending','confirmed','active','completed','cancelled','disputed');
create type deposit_status as enum ('pending','authorized','released','partially_captured','captured','refunded');

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text,
  role user_role not null default 'renter',
  country text,
  city text,
  avatar_url text,
  verification_status verification_status not null default 'pending',
  created_at timestamptz not null default now()
);

create table vehicles (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid not null references profiles(id) on delete cascade,
  make text not null,
  model text not null,
  year int not null check (year >= 1990),
  category text not null,
  transmission text not null,
  city text not null,
  plate_number text not null,
  vin text,
  daily_price numeric(10,2) not null check (daily_price > 0),
  security_deposit numeric(10,2) not null default 0,
  description text,
  status verification_status not null default 'pending',
  is_active boolean not null default false,
  created_at timestamptz not null default now()
);

create table vehicle_photos (
  id uuid primary key default uuid_generate_v4(),
  vehicle_id uuid not null references vehicles(id) on delete cascade,
  url text not null,
  sort_order int not null default 0
);

create table bookings (
  id uuid primary key default uuid_generate_v4(),
  renter_id uuid not null references profiles(id),
  vehicle_id uuid not null references vehicles(id),
  recipient_name text,
  recipient_phone text,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  pickup_type text not null,
  pickup_location text not null,
  rental_amount numeric(10,2) not null,
  service_fee numeric(10,2) not null,
  delivery_fee numeric(10,2) not null default 0,
  security_deposit numeric(10,2) not null,
  total_amount numeric(10,2) not null,
  status booking_status not null default 'pending',
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create table payments (
  id uuid primary key default uuid_generate_v4(),
  booking_id uuid not null references bookings(id),
  provider text not null,
  provider_payment_id text,
  rental_status text not null default 'pending',
  deposit_status deposit_status not null default 'pending',
  amount numeric(10,2) not null,
  currency text not null default 'USD',
  created_at timestamptz not null default now()
);

create table inspections (
  id uuid primary key default uuid_generate_v4(),
  booking_id uuid not null references bookings(id),
  inspection_type text not null check (inspection_type in ('pickup','return')),
  odometer int,
  fuel_level text,
  notes text,
  submitted_by uuid not null references profiles(id),
  created_at timestamptz not null default now()
);

create table inspection_photos (
  id uuid primary key default uuid_generate_v4(),
  inspection_id uuid not null references inspections(id) on delete cascade,
  url text not null,
  angle text,
  created_at timestamptz not null default now()
);

create table claims (
  id uuid primary key default uuid_generate_v4(),
  booking_id uuid not null references bookings(id),
  submitted_by uuid not null references profiles(id),
  amount_requested numeric(10,2) not null,
  reason text not null,
  status text not null default 'pending',
  admin_decision text,
  approved_amount numeric(10,2),
  created_at timestamptz not null default now()
);

create table reviews (
  id uuid primary key default uuid_generate_v4(),
  booking_id uuid not null references bookings(id),
  reviewer_id uuid not null references profiles(id),
  reviewee_id uuid not null references profiles(id),
  rating int not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);

alter table profiles enable row level security;
alter table vehicles enable row level security;
alter table bookings enable row level security;
alter table payments enable row level security;
alter table inspections enable row level security;
alter table claims enable row level security;

create policy "public vehicles visible"
on vehicles for select
using (is_active = true and status = 'approved');

create policy "owners manage own vehicles"
on vehicles for all
using (auth.uid() = owner_id)
with check (auth.uid() = owner_id);

create policy "renters see own bookings"
on bookings for select
using (auth.uid() = renter_id);

create policy "owners see bookings for their vehicles"
on bookings for select
using (
  exists (
    select 1 from vehicles
    where vehicles.id = bookings.vehicle_id
    and vehicles.owner_id = auth.uid()
  )
);
